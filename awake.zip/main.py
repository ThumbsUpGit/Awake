import time

def slow_print(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.05)
    print()

thewoods = {
    'The campfire': {
       
        'north': 'the cabin',
        'south': 'the whispering tree line',
        'east': 'the bush path',
        'item': None,
    },
    'the cabin': {
        'north': 'the old bedroom',
        'south': 'The campfire',
        'east': 'the living room',
        'item': None,
    },
    'the old bedroom': {
        'north': 'bed',
        'item': 'lighter',
    },
    'the whispering tree line':{
        'north':'The campfire',
        'item': None,
    },
     'the bush path':{
        'east':'The campfire',
        'item': 'paper',
    },
    'the living room':{
        'north': 'the couch',
        'item': None,
        'option one': 'light the fire place',
        'option two': 'search the room',
        'option three': 'look around',
    },
    'the couch':{
        'item': 'club',
    },
    'bed':{
      
    }
}

current_room = 'The campfire'
inventory = []

actions = ["move [direction]", "pick up", "read note", "Think", "option one", "option two", "action three", "quit"]

def show_status():
    global current_room
    if current_room == 'The campfire': 
        slow_print("You look into the vast void around the dimly lit campfire, the cicadas' noise dies out.")
    if current_room == 'the cabin':
        slow_print("the floor boards creak under your feet as you enter the old cabin, you know the only way to escape them is to sleep, you need to sleep")
    print(f"\nYou are in the {current_room}.")
    print("Inventory:", inventory)
    
    if current_room == 'bed':
        slow_print("you lay down in bed, the covers slide above you, trapping you in your mind, you hear a bang on the door, what do you do?")
        slow_print("action 3. hide under the bed\n action1. pretend to sleep\n action 2. face it head on\n")
    
    if current_room == 'the living room':
        slow_print("option one: light fireplace, option two: search the room, option 3: look around")
        
    if current_room == 'the whispering tree line':
        slow_print("option one, look around, option two, listen")
    
    if current_room == 'the cabin':
       print(" _______________________________________________")
       print("|-|/----|------------------------_|--------|----|")
       print("|-|/----|-----------------____--| |--------|----|")
       print("|-|/----| \__            |     /| |--------|----|")
       print("|-|/____|   /            |o   / | |--------|----|")
       print("|-|     |   \_           |___|  | |        |----|")
       print("|-|     |   / /|        |____|  | |        |----|")
       print("|-|     | _/  ||       |_____|  | |        |----|")
       print("|-|     |/    ||       |_____|  | |        |----|")
       print("|-|/----|     ||______|______|O | |        |----|")
       print("|-|     |    /|/             |  | |        |----|")
       print("|-|     |   //               |  | |        |----|")
       print("|-|     |  //                |  | |        |----|")
       print("|-|\____|_//_________________\  | |________|----|")
       print("|-|\----|//----[-------]------\ | |--------|----|")
       print("|-|\----|/-----[-------]-------\|_|--------|----|")
       print("|_|\____|______[_______]__________|________|____")
        

    if 'item' in thewoods[current_room] and thewoods[current_room]['item']:
        print("You see a", thewoods[current_room]['item'])

    available_directions = [direction.capitalize() for direction in thewoods[current_room] if direction in ['north', 'south', 'east', 'west']]
    
    if available_directions:
        print("You can move in the following directions:", ', '.join(available_directions))
    else:
        print("There are no obvious exits here.")

    print("Available actions:", ', '.join(actions))  
    print("-" * 20)

def start_game():
    slow_print("your actions are told and options are listed, don't stare into the fog")
    ready = input("Are you ready to wake up? (yes or no): ").lower()
    return ready == 'yes'

def move(direction):
    global current_room
    if direction in thewoods[current_room]:
        current_room = thewoods[current_room][direction]
        return False
    else:
        print("You can't move in that direction.")
        return False

def pick_up_item():
    global current_room
    if 'item' in thewoods[current_room] and thewoods[current_room]['item']:
        item = thewoods[current_room]['item']
        inventory.append(item)
        thewoods[current_room]['item'] = None
        print(f"You picked up the {item}.")
    else:
        print("There's nothing to pick up here.")
    if item == 'paper' and 'read paper' not in actions:
        actions.append("read paper")
        slow_print("after you pick up the paper expecting it to be destroyed from the weather from the past storms you find it ledgable")
        # i was too lazy to a bigger function here so I left the paper as is, my code
    else:
        slow_print("theres nothing here.")

def read_note():
       print(" _______________________________________________")
       print("|-----/-------------------------------\--------|")
       print("|----/---------------------------------\-------|")
       print("|---/-----------------------------------\------|")
       print("|--/_____________________________________\-----|")
       print("|-|                                       |----|")
       print("|-| dear Mr. Walker                       |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|-|_______________________________________|----|")
       print("|----------------------------------------------|")
       print("|----------------------------------------------|")
       print("|______________________________________________")
       slow_print("you try to read the note but the ink that used to last was washed away, you read the name Mr. Walker but his note was lost to time.")
       return
    
def use_light():
    if current_room == 'the living room':
        slow_print("the fireplace flows with life, leaving the air feeling fresh and safe, no more dreading cold air from the ones outside,")
        

def read_paper():
       print(" _______________________________________________")
       print("|-|                                       |----|")
       print("|-|  New York Times-1992                  |----|")
       print("|-|    ____________                       |----|")
       print("|-|   |  _______   |                      |----|")
       print("|-|   | |       |  |  worry as a fog      |----|")
       print("|-|   | | .   . |  |  sweeps over the     |----|")
       print("|-|   | | ____  |  |  nation as europe    |----|")
       print("|-|   | |_______|  |  is condensed, it    |----|")
       print("|-|   |            |  seems to open up    |----|")
       print("|-|   |____________|  around buildings    |----|")
       print("|-|   and other areas randomly, right     |----|")
       print("|-|   now Syria and most of the middle    |----|")
       print("|-|   east is gone cover in the-          |----|")
       print("|-|                                       |----|")
       print("|-|                                       |----|")
       print("|_|_______________________________________|____|")
       slow_print("you read the date on the paper, 1992, you forgot that its 1992 already, the paper holds a joke but you can't read it, a shame.")
       return
def think_out():
    if current_room == 'The campfire':
        slow_print("there must be something out there for the cicadas to be afraid, I hope its not one of those, things.")
    if current_room != 'The campfire':
        slow_print("your mind has nothing to say")
    if current_room == 'the old bedroom':
        slow_print("this bed looks so old, is that a coffee stain?")
        
def movement():
     if current_room == 'bed':
        slow_print("As you fall asleep in this old bed, you hear a loud bang, it sounds like the door was knocked off its hinges.")
     if current_room == 'the living room':
         slow_print("you enter the old room, water dripping from the celing and the carpet charded from the fire place out of life")
         
def action_one():
    if current_room == 'bed':
            slow_print("You close your eyes and feel the dread this creature brings. As a fog swallows your room, you hear a loud bang. You go to check, and the creature is gone.")
            slow_print("You need to get out of here.")
            slow_print("to be continued")
            exit()
def action_two():
    if current_room == 'bed':
            slow_print("You get out of bed with confidence. You find a nailed wooden plank and rip it out of the ground.")
            slow_print("You are about to open the door when it gets bashed down, knocking you off your feet.")
            slow_print("You try to get up, but the void has found you. Game over.")
            return  # ends the game here because wrong choice
def action_three():
    if current_room == 'bed':
            slow_print("You try to hide under the bed, trembling. The creature walks in, its heavy footsteps echoing in the room.")
            slow_print("It looks directly at you under the bed. Game over.")
            return  # Ends the game here because of wrong choice again
    else:
        print("not in this room")
        return 
    # living room options
def action_oneliving():
    if current_room == 'the living room':
        slow_print("the spark you send lights the room a blaze in colors, you feel safe now knowing most will stay away from the warmth")
        return
    if current_room == 'bed':
            slow_print("You close your eyes and feel the dread this creature brings. As a fog swallows your room, you hear a loud bang. You go to check, and the creature is gone.")
            slow_print("You need to get out of here.")
            slow_print("to be continued")
            exit()
    if current_room == 'the whispering tree line':
       print(" _______________________________________________")
       print("|----------------------------------------------|")
       print("|-----------/\---------------------------------|")
       print("|----------/--\--------------------------------|")
       print("|---------/----\-------------------------------|")
       print("|--------/------\------------------------------|")
       print("|-------/--------\-----------------------------|")
       print("|------/__________\----------------------------|")
       print("|--/\-/-----||-----\---------------------------|")
       print("|-/--\------||---------------------------------|")
       print("|/____\-----||---------------------------------|")
       print("|--||-------||---------------------------------|")
       print("|--||-------||---------__----------------------|")
       print("|--||-------||---0-0-----{--}------------------|")
       print("|--||-------||----------{----}----/\--/\-------|")
       print("|MMMMMMMMMMM||MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM|")
       print("|______________________________________________")
       slow_print("the dark void plunges the tree line into obscurity, you see what you think are eyes staring, shining at you, but its not stalking, its hiding, from what?")
       return
   
    else:
        return
    
def action_twoliving():
    if current_room == 'the living room':
        slow_print("you search the tiring room, under the sofa, around the corners, but there is nothing to be found but dust")
        return
    if current_room == 'bed':
        slow_print("You get out of bed with confidence. You find a nailed wooden plank and rip it out of the ground.")
        slow_print("You are about to open the door when it gets bashed down, knocking you off your feet.")
        slow_print("You try to get up, but the void has found you. Game over.")
        return  # ends the game here because wrong choice
    if current_room == 'the whispering tree line':
        slow_print("you hear the voices, they gain volume as you try listening more, but you trip over a rock, lol")
        return
    
    else:
        print("sorry not vaild input")
        return
def action_threeliving():
    if current_room == 'the living room':
       print(" _______________________________________________")
       print("|----------------_____________-----------------|")
       print("|---------------/             \----------------|")
       print("|---------------|   mirror    |----------------|")
       print("|---------------|             |----------------|")
       print("|-----------|_____________________|------------|")
       print("|----------/                       \-----------|")
       print("|---------|-------------------------|----------|")
       print("|---------|-------fire place--------|----------|")
       print("|---------|-------------------------|----------|")
       print("|---------|_________________________|----------|")
       print("|-________-------------------------------------|")
       print("|/--------\------------------------------------|")
       print("||-couch--|------------------------------------|")
       print("||________|------------------------------------|")
       print("|||------||------------------------------------|")
       print("|______________________________________________")
       slow_print("you look at the walls and notice a painting is missing, alot of things were stolen from here when the first fog came")
       return 
    if current_room =='bed':
        slow_print("You try to hide under the bed, trembling. The creature walks in, its heavy footsteps echoing in the room.")
        slow_print("It looks directly at you under the bed. Game over.")
        return  # Ends the game here because of wrong choice again
    else:
        print("not in this room")
        return 
    def options():
        if current_room == 'the whispering tree line':
            slow_print("option one, look around, option two, listen")
            
        

def main():
    if start_game():
        while True:
            show_status()
            command = input("Enter your command: ").lower().strip()

            if command in ['quit', 'exit']:
                slow_print("You fall to the ground, everything fades to black as you hear the bushes rattle, a fadded imagie emerges, you feel the dread as it approaches.")
                break
            elif command.startswith("move "):
                move(command.split(" ")[1])
            elif command == "pick up":
                pick_up_item()
            elif command == "read note":
                read_note()
            elif command == "think":
                think_out()
            elif command == "read paper":
                read_paper()
            elif command == "movements":
                movement()
            elif command == "action one":
                action_one()
            elif command == "action two":
                action_two()
            elif command == "action three":
                action_three()
            elif command == "use lighter":
                use_lighter()
            elif command == "option one":
                action_oneliving()
            elif command == "option two":
                action_twoliving()
            elif command == "option three":
                action_threeliving()
            elif command == 'look around':
                look_around()
            elif command == 'options':
                options()
            else:
                print("Invalid command! Please try again.")

if __name__ == "__main__":
    main()